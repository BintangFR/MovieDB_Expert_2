package com.example.moviedb.core.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}