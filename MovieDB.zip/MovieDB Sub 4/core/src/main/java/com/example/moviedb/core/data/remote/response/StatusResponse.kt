package com.example.moviedb.core.data.remote.response

enum class StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}